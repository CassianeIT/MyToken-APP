//
//  ViewModel.swift
//  MyTokens
//
//  Created by Curitiba on 18/02/22.
//

import Foundation
import UIKit

class ViewModel: UIViewController {

    override func viewDidLoad() {
        
    }
    
//    func showData(id: String, symbol: String, name: String, detailCoinDescription: Description, image: Images, marketData: MarketData) {
//   //  func showData(viewModel: DetailCoin) {
//
//         var detailCoin = DetailCoinView()
//         detailCoin.coinName = name
//         detailCoin.coinSymbol = symbol
//         detailCoin.coinPriceBRL = marketData.currentPrice.brl
//         detailCoin.coinPriceUSD = marketData.currentPrice.usd
//         detailCoin.coinPriceEUR = marketData.currentPrice.eur
//         detailCoin.coinPriceBTC = marketData.currentPrice.btc
//         print(name)
//     }
//}
}
